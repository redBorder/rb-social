package net.redborder.social.util;

/**
 * Created by andresgomez on 29/12/14.
 */
public enum SensorType {
    TWITTER, INSTAGRAM
}
