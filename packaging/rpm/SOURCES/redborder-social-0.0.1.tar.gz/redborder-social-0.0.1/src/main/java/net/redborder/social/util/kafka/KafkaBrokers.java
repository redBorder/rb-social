package net.redborder.social.util.kafka;

/**
 * Created by crodriguez on 5/12/14.
 */
public interface KafkaBrokers {
    public String get();
    public void reload();
}
